//
//  AVTextField.h
//  paas
//
//  Created by Summer on 13-3-28.
//  Copyright (c) 2013年 AVOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AVTextField : UITextField

@end
