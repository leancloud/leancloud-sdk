//
//  NSString+MD5.h
//  paas
//
//  Created by Summer on 13-3-22.
//  Copyright (c) 2013年 AVOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)

- (NSString *)MD5String;

@end
